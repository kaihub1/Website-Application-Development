const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);

});

app.post("/submit-contact", (req, res) => {
    const { myName, myEmail, myReason, myComments } = req.body;

    // Validate Name
    if (!myName || typeof myName !== "string" || myName.trim() === "") {
        return res.status(400).json({ error: "Name is required." });
    }

    // Validate Email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!myEmail || !emailRegex.test(myEmail)) {
        return res.status(400).json({ error: "Valid email is required." });
    }

    // Validate Reason
    if (!myReason || typeof myReason !== "string" || myReason.trim() === "") {
        return res.status(400).json({ error: "Reason is required." });
    }

    // Validate Comments
    if (!myComments || typeof myComments !== "string" || myComments.trim() === "") {
        return res.status(400).json({ error: "Comments are required." });
    }

    // Log data

    console.log("Form Data Received:", { myName, myEmail, myReason, myComments });

    // Send back the data
    res.status(200).json({
        message: "Form data received successfully!",
        receivedData: { myName, myEmail, myReason, myComments },
    });
});