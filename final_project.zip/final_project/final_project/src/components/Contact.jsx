import React, { useState } from "react";

function Contact() {
    // State to manage form data and server response
    const [formData, setFormData] = useState({
        myName: "",
        myEmail: "",
        myReason: "",
        myComments: "",
    });

    const [responseMessage, setResponseMessage] = useState("");

    // Handle form input changes
    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    // Handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault(); // Prevent default form submission behavior
        try {

            const response = await fetch("http://localhost:5000/submit-contact", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(formData),
            });

            const data = await response.json();
            if (response.ok) {
                setResponseMessage(`
${data.message}
- Name: ${data.receivedData.myName}
- Email: ${data.receivedData.myEmail}
- Reason: ${data.receivedData.myReason}
- Comments: ${data.receivedData.myComments}
`);
                // Reset the form
                setFormData({ myName: "", myEmail: "", myReason: "", myComments: "" });
            } else {
                setResponseMessage(data.error || "Something went wrong.");
            }
        } catch (error) {
            console.error("Error:", error);
            setResponseMessage("Failed to submit the form. Try again later.");
        }
    };

    return (

        <main>
            <h2>Contact Fish Creek</h2>
            <p>Fill out the form below to contact Fish Creek. All information is required.</p>

            {/* Form */}
            <form onSubmit={handleSubmit}>
                <label htmlFor="myName">Name:</label>
                <input
                    type="text"
                    id="myName"
                    name="myName"
                    value={formData.myName}
                    onChange={handleChange}
                    required
                />

                <label htmlFor="myEmail">E-mail:</label>
                <input
                    type="email"
                    id="myEmail"
                    name="myEmail"
                    value={formData.myEmail}
                    onChange={handleChange}
                    required
                />

                <label htmlFor="myReason">Reason for Contact:</label>

                <input
                    list="reasons"
                    id="myReason"
                    name="myReason"
                    value={formData.myReason}
                    onChange={handleChange}
                    required
                />
                <datalist id="reasons">
                    <option value="New Patient" />
                    <option value="Appointment" />
                    <option value="House Call" />
                    <option value="Information" />
                    <option value="Ask the Vet" />
                </datalist>

                <label htmlFor="myComments">Comments:</label>
                <textarea
                    id="myComments"
                    name="myComments"
                    rows="2"
                    cols="20"
                    value={formData.myComments}
                    onChange={handleChange}
                    required
                ></textarea>

                <input type="submit" id="mySubmit" value="Send Now" />
            </form>

            {/* Response Message */}
            {responseMessage && <p>{responseMessage}</p>}
        </main>
    );
}

export default Contact;